#ifndef COMMON_INCLUDE_H
#define COMMON_INCLUDE_H

// std
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iosfwd> // 模板和typedef
#include <iostream>
#include <sstream>
#include <memory>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <algorithm>
#include <chrono> //计时器
#include <math.h>
#include<time.h>
#include <boost/shared_ptr.hpp>
// pcl
#include <pcl/common/common.h> //pcl::getMinMax3D
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/io/ply_io.h>
// #include <pcl/visualization/cloud_viewer.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/impl/io.hpp> //copyPointCloud
#include <pcl/filters/filter.h>
#include <pcl/common/transforms.h> // pcl::transformPointCloud
#include <pcl/conversions.h>

// ros
// #include <pcl_ros/point_cloud.h>  //允许你发布和订阅pcl::PointCloud<T>对象作为ROS消息
// #include <pcl_ros/transforms.h>         // pcl_ros::transformPointCloud
// #include <pcl_ros/impl/transforms.hpp>  // 自定义点类型的转换

// 自定义点云类型调用pcl处理函数需添加.hpp的头文件
#include <pcl/filters/impl/passthrough.hpp>
#include <pcl/impl/pcl_base.hpp>
// #include <pcl/kdtree/impl/kdtree_flann.hpp>
// #include <pcl/search/impl/kdtree.hpp>
// #include <pcl/search/impl/organized.hpp>

// //opencv
// # include <opencv2/opencv.hpp>  // 模块头文件包含文件
// # include <opencv2/core/core.hpp>
// # include <opencv2/highgui/highgui.hpp>
// # include <opencv2/imgproc/imgproc.hpp>

// #include "common_include.h"

#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>

using namespace std;


// 自定义点云类型-- 常用
struct PointAllPLY
{
    PCL_ADD_POINT4D; // 该点类型有4个元素
    float intensity; // laser intensity reading
    float nx;
    float ny;
    float nz;
    u_char r;
    u_char g;
    u_char b;
    u_char alpha;
    float radius;
    float confidence;
    float curvature;
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW // 确保new操作符对齐操作
} EIGEN_ALIGN16;

POINT_CLOUD_REGISTER_POINT_STRUCT(
    PointAllPLY, //注册点类宏
    (float, x, x)(float, y, y)(float, z, z)(float, nx, nx)(float, ny, ny)(float, nz, nz)
    (u_char, r, r)(u_char, g, g)(u_char, b, b)(u_char, alpha, alpha)(float, radius, radius)
    (float, confidence, confidence)(float, curvature, curvature))



struct PointXYZIR
{
    PCL_ADD_POINT4D;                // 该点类型有4个元素
    float intensity;                // laser intensity reading
    uint16_t ring;                  // laser ring number
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW // 确保new操作符对齐操作
} EIGEN_ALIGN16;

POINT_CLOUD_REGISTER_POINT_STRUCT(
    PointXYZIR, //注册点类宏
    (float, x, x)(float, y, y)(float, z, z)(float, intensity, intensity)(uint16_t, ring, ring))

//////////////////////////////////////////////////////////////////////

struct Label
{
    string type; // object type as car, pedestrian or cyclist,...
    string trackerID;
    bool state; //0: static/1:dynamic
    double cx;  // front
    double cy;  // left
    double cz;  // top
    double w;
    double l;
    double h;
    double yaw; // rotation_y
    // Label(string type, string trackerID, bool state, double cx, double cy, double cz,
    //         double w, double l, double H, double yaw) {}
};

struct CANSteer
{
    double timestamps;
    double steer_angle;
    double steer_speed;
};

struct CANVel
{
    double timestamps;
    double speed;
};

struct GPS
{
    double timestamps;
    double long_rel;
    double lat_rel;
    double in_height;
    double tilt_roll;
    double tilt_pitch;
    double tilt_yaw;
    double vel_x;
    double vel_y;
    double vel_z;
    double std_dev_x;
    double std_dev_y;
    double std_dev_z;
    double std_dev_roll;
    double std_dev_pitch;
    double std_dev_yaw;
    double std_dev_vel_x;
    double std_dev_vel_y;
    double std_dev_vel_z;
    double abs_lat;
    double abs_long;
};


class MyFrame {
    public: 
        
        // pcl::PointCloud<PointXYZIR>::Ptr cloud;
        pcl::PointCloud<PointXYZIR>::Ptr cloud {new pcl::PointCloud<PointXYZIR>}; //类成员指针变量的new方法
        vector<Label> label;
        vector<CANSteer> can_steer;
        vector<CANVel> can_vel;
        vector<GPS> gps;
        MyFrame(string scenario_dir, int index);
        //~MyFrame() { cout << "release num " << this->index << " frame." << endl; }
        ~MyFrame() {}
    private:
        int index;
        int loadPlyCloud(std::string file_name, pcl::PointCloud<PointXYZIR>::Ptr cloud_in);
        bool loadLabel(string file_name, vector<Label> &label);
        bool loadSteer(string file_name, vector<CANSteer> &steer);
        bool loadGPS(string file_name, vector<GPS> &gps);
        bool loadVel(string file_name, vector<CANVel> &vel);
}; 



int TraverseDir_Num(std::string);//返回该文件夹的文件个数


#endif
