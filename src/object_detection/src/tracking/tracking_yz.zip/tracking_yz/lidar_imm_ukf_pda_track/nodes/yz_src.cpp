#include "yz_include.h"



int MyFrame::loadPlyCloud(std::string plydir, pcl::PointCloud<PointXYZIR>::Ptr cloud)
{
  pcl::PointCloud<PointAllPLY>::Ptr cloud_(new pcl::PointCloud<PointAllPLY>);
  if (pcl::io::loadPLYFile<PointAllPLY>(plydir, *cloud_) == -1)
  {
    PCL_ERROR("Couldn't read file test_ply.pcd \n");
    return (-1);
  }
  cloud->points.resize(cloud_->width * cloud_->height);

  for (size_t i = 0; i < cloud_->points.size(); ++i)
  {
    cloud->points[i].x = cloud_->points[i].x;
    cloud->points[i].y = cloud_->points[i].y;
    cloud->points[i].z = cloud_->points[i].z;
    cloud->points[i].intensity = cloud_->points[i].radius / 255;
    cloud->points[i].ring = (uint16_t)cloud_->points[i].confidence;
  }
  return 0;
}

bool MyFrame::loadLabel(string file_name, vector<Label> &label)
{

  FILE *fp = fopen(file_name.c_str(), "r");
  if (!fp)
  {
    return 0;
  }
  while (!feof(fp))
  {
    char type[16];
    char ID[64];
    char state[8];
    Label g;
    if (fscanf(fp, "%[^,],%[^,],%[^,],%lf,%lf,%lf,%lf,%lf,%lf,%lf\n",
               type, ID, state, &g.cx, &g.cy, &g.cz,
               &g.w, &g.l, &g.h, &g.yaw))
    { //ignore blank
      g.type = type;
      g.trackerID = ID;
      if (strcmp(state, "static"))
        g.state = false;
      else if (strcmp(state, "dynamic"))
        g.state = true;
      else
        return 0;

      label.push_back(g);
    }
  }
  fclose(fp);
  return 1;
}

bool MyFrame::loadSteer(string file_name, vector<CANSteer> &steer)
{
  FILE *fp = fopen(file_name.c_str(), "r");
  if (!fp)
  {
    return 0;
  }
  char tmp[255];
  fscanf(fp, "%[^\n]%*c", tmp);
  while (!feof(fp))
  {
    CANSteer st;
    if (fscanf(fp, "%lf,%lf,%lf,\n", &st.timestamps, &st.steer_angle, &st.steer_speed))
    {

      steer.push_back(st);
    }
  }
  fclose(fp);
  return 1;
}

bool MyFrame::loadGPS(string file_name, vector<GPS> &gps)
{
  FILE *fp = fopen(file_name.c_str(), "r");
  if (!fp)
  {
    return 0;
  }
  char tmp[1024];
  fscanf(fp, "%*[^\n]%*c", tmp);
  while (!feof(fp))
  {
    GPS g;
    if (fscanf(fp, "%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf\n",
               &g.timestamps, &g.long_rel, &g.lat_rel, &g.in_height, &g.tilt_roll,
               &g.tilt_pitch, &g.tilt_yaw, &g.vel_x, &g.vel_y, &g.vel_z, &g.std_dev_x,
               &g.std_dev_y, &g.std_dev_z, &g.std_dev_roll, &g.std_dev_pitch, &g.std_dev_yaw,
               &g.std_dev_vel_x, &g.std_dev_vel_y, &g.std_dev_vel_z, &g.abs_lat, &g.abs_long))
    {

      gps.push_back(g);
    }
  }
  fclose(fp);
  return 1;
}

bool MyFrame::loadVel(string file_name, vector<CANVel> &vel)
{
  FILE *fp = fopen(file_name.c_str(), "r");
  if (!fp)
  {
    return 0;
  }
  char tmp[255];
  fscanf(fp, "%[^\n]%*c", tmp);
  while (!feof(fp))
  {
    CANVel v;
    if (fscanf(fp, "%lf,%lf,\n", &v.timestamps, &v.speed))
    {
      vel.push_back(v);
    }
  }
  fclose(fp);
  return 1;
}

MyFrame::MyFrame(string scenario_dir, int index)
{
  this->index = index;
  char char_index[4];
  sprintf(char_index, "%03d", index);
  string string_index(char_index);
  string steer_name = "CAN_steer_" + string_index + ".csv";
  string vel_name = "CAN_vel_" + string_index + ".csv";
  string gps_name = "gps_" + string_index + ".csv";
  string label_name = "labels_3d1_" + string_index + ".txt";
  string cloud_name = "pointcloud1_" + string_index + ".ply";
  this->loadPlyCloud(scenario_dir + "/" + cloud_name, this->cloud);
  this->loadSteer(scenario_dir + "/" + steer_name, this->can_steer);
  this->loadVel(scenario_dir + "/" + vel_name, this->can_vel);
  this->loadGPS(scenario_dir + "/" + gps_name, this->gps);
  this->loadLabel(scenario_dir + "/" + label_name, this->label);
  std::cout << "frame done." << endl;
}



int  TraverseDir_Num(string scenario_dir)//返回该文件夹的文件个数
{
  const char* strVideoDir = scenario_dir.c_str();
	//遍历目录
	static  int num = 0;
	DIR*		dp;
	struct dirent *entry;
	struct stat statbuf;
	dp = opendir(strVideoDir);
	if(!dp)
	{
		cout << "No such file or directory:" << scenario_dir;
		return -1;
	}
	chdir(strVideoDir);
	while((entry = readdir(dp)) != nullptr)
	{
		lstat(entry->d_name, &statbuf);
		if(S_ISDIR(statbuf.st_mode))
		{
			if(!strcmp(".",entry->d_name) || !strcmp("..",entry->d_name))
			{
				continue;
			}
			char		strNewDir[256];
			sprintf(strNewDir, "%s/%s", strVideoDir, entry->d_name);
			TraverseDir_Num(strNewDir);
		}
		else
		{
			num += 1;
		}
 
	};
	
	chdir("..");
	closedir(dp);
	return num;
}



// namespace precision_tracking {

// namespace track_manager_color {
// void track(
//            vector<MyFrame> *data, 
//            const precision_tracking::track_manager_color::TrackManagerColor& track_manager,
//            const precision_tracking::Params& params,
//            const bool use_precision_tracker,
//            const bool do_parallel,
//            std::vector<TrackResults>* velocity_estimates) {

//   // const std::vector< boost::shared_ptr<precision_tracking::track_manager_color::Track> >& tracks =
//   //     track_manager.tracks_;


//   const int num_threads = do_parallel ? 8 : 1;

//   std::vector<precision_tracking::Tracker> trackers;
//   for (int i = 0; i < num_threads; ++i) {
//     precision_tracking::Tracker tracker(&params);
//     if (use_precision_tracker) {
//       tracker.setPrecisionTracker(
//           boost::make_shared<precision_tracking::PrecisionTracker>(&params));
//     }
//     trackers.push_back(tracker);
//   }

//   // velocity_estimates->resize(tracks.size());

//   std::ostringstream hrt_title_stream;
//   //hrt_title_stream << "Total time for tracking " << tracks.size() << " objects";
//   precision_tracking::HighResTimer hrt(hrt_title_stream.str(),
//                                        do_parallel ? CLOCK_REALTIME :
//                                                      CLOCK_PROCESS_CPUTIME_ID);
//   hrt.start();

//   // Iterate over all frames.
//   #pragma omp parallel for num_threads(num_threads)
//   for (int size_t = 0; i < data->size(); ++i) {
//     MyFrame frame = data[i];
//     precision_tracking::Tracker& tracker = trackers[omp_get_thread_num()];

//     // Reset the tracker for this new track.
//     tracker.clear();

//     // Extract frames.
//     const boost::shared_ptr<precision_tracking::track_manager_color::Track>& track = tracks[i];
//     const std::vector< boost::shared_ptr<precision_tracking::track_manager_color::Frame> > frames =
//         track->frames_;

//     // Structure for storing estimated velocities for this track.
//     TrackResults track_estimates;
//     track_estimates.track_num = track->track_num_;

//     // Iterate over all objects per frame
//     for (size_t j = 0; j < frame.label.size(); ++j) {
//       Label gtlabel = frame.label;

//       // Get the sensor resolution.
//       double sensor_horizontal_resolution;
//       double sensor_vertical_resolution;
//       const Eigen::Vector3f centroid_local_coordinates;
//       centroid_local_coordinates <<  gtlabel.cx << gtlabel.cy << gtlabel.cz;
//       precision_tracking::getSensorResolution(
//             centroid_local_coordinates, &sensor_horizontal_resolution,
//             &sensor_vertical_resolution);

//       // Track object.
//       Eigen::Vector3f estimated_velocity;
//       tracker.addPoints(frame->cloud_, frame->timestamp_,
//                           sensor_horizontal_resolution,
//                           sensor_vertical_resolution,
//                           &estimated_velocity);

//       // The first time we see this object, we don't have a velocity yet.
//       // After the first time, save the estimated velocity.
//       if (j > 0) {
//         track_estimates.estimated_velocities.push_back(estimated_velocity);

//         // By default, don't ignore any frames.
//         track_estimates.ignore_frame.push_back(false);
//       }
//     }
//     (*velocity_estimates)[i] = track_estimates;
//   }


//   hrt.stop();
//   hrt.print();

//   const double ms = hrt.getMilliseconds();
//   //printf("Mean runtime per frame: %lf ms\n", ms / total_num_frames);
// }

// // TrackManagerColor::TrackManagerColor(vector<MyFrame> *data) : 
// //   serialization_version_(TRACKMANAGER_SERIALIZATION_VERSION),
// //   tracks_(vector< boost::shared_ptr<Track> >()) 
// // {
// //   cout << "Now loading " << data->size() << " frames to TrackManage." << endl;
// //   tracks_.clear();
// //   serialization_version_ = 2;
// //   for (int i=0; i<data->size(); i++) {
// //     boost::shared_ptr<Track> tr(new Track());
// //     tr->serialization_version_ = 2;
// //     tr->track_num_ = data[i].label.size();
// //     tr->label_ = data[i].label
// //   }
// // }

// }
// }
