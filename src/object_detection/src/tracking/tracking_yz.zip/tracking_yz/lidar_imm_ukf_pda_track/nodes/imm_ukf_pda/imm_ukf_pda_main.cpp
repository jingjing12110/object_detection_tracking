/*
 * Copyright 2018-2019 Autoware Foundation. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/point_types.h>
#include <iostream>

#include "imm_ukf_pda.h"
#include "yz_include.h"

#include "autoware_msgs/DetectedObject.h"
#include "autoware_msgs/DetectedObjectArray.h"

std::string scenario_dir =
    "/media/yz/DATA/MyProject/dataset/lasernet_dataset/icra_benchmark/"
    "scenario_001";

void loadInput(MyFrame frame, autoware_msgs::DetectedObjectArray& input,
               int frame_id) {
  input.header.stamp.fromSec(frame.can_vel[4].timestamps);
  input.header.seq = frame_id;
  for (int i = 0; i < frame.label.size(); i++) {
    autoware_msgs::DetectedObject object;
    object.label = frame.label[i].type;
    object.pose.position.x = frame.label[i].cx;
    object.pose.position.y = frame.label[i].cy;
    object.pose.position.z = frame.label[i].cz;
    input.objects.push_back(object);
    // input.objects[i].pose.position.x = frame.label[i].cx;
    // input.objects[i].pose.position.y = frame.label[i].cy;
    // input.objects[i].pose.position.z = frame.label[i].cz;
  }
}

int main(int argc, char** argv) {
  ros::init(argc, argv, "imm_ukf_pda_tracker");

  int nums = TraverseDir_Num(scenario_dir) / 5;

  ImmUkfPda app;
  clock_t start, finish;

  for (int i = 0; i < nums; i++) {
    MyFrame frame = MyFrame(scenario_dir, i);
    start = clock();

    autoware_msgs::DetectedObjectArray detected_objects_output;
    autoware_msgs::DetectedObjectArray input;
    loadInput(frame, input, i);

    app.tracker(input, detected_objects_output);

    finish = clock();
    double per_time = (double)(finish - start) / CLOCKS_PER_SEC;
    std::cout << "time: " << per_time << endl;
    // std::cout << detected_objects_output.objects[0].pose.position.x << endl;
  }
  // ImmUkfPda app;
  // app.run();
  ros::spin();
  return 0;
}
